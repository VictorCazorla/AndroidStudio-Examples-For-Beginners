package com.example.bd_room_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

/* BY CHATGPT:
El error que estás experimentando es común en Android cuando intentas realizar operaciones de base
 de datos en el hilo principal (main thread). Para evitar bloquear la interfaz de usuario (UI),
 Room impone la restricción de que las operaciones de base de datos deben realizarse en un hilo
 separado.

Aquí hay algunas opciones que puedes considerar para solucionar este problema:

    1.- Utilizar AsyncTask:
    Puedes utilizar AsyncTask para ejecutar tus operaciones de base de datos en un hilo separado.
    Room tiene soporte integrado para AsyncTask que facilita la ejecución de operaciones en segundo
     plano y la actualización de la interfaz de usuario en el hilo principal.

    2.- Utilizar Coroutines:
    Puedes usar Kotlin Coroutines para realizar operaciones de base de datos de manera asíncrona.
    Room tiene soporte nativo para coroutines.

    Asegúrate de que estás llamando a tus métodos de base de datos en un contexto de Dispatchers.
    IO para ejecutar las operaciones en un hilo separado.

    El uso de coroutines es una práctica moderna y recomendada en Kotlin y Android. Si aún no estás
    utilizando coroutines en tu proyecto, considera agregar la dependencia de kotlinx-coroutines-android
    a tu archivo build.gradle y aprender sobre cómo integrar coroutines en tu código.

    Recuerda que el hilo principal se utiliza para actualizar la interfaz de usuario, y las
    operaciones intensivas deben realizarse en segundo plano para no bloquear la UI y proporcionar
    una experiencia de usuario fluida.

 */


//CORRUTINAS NECESARIAS PARA ATACAR DATOS EN ROOM
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
            val userDao = UserDatabase.getDatabase(this@MainActivity).userDao()

            // Insertar un usuario
            val user = User(uid = 1, firstName = "Mario1", lastName = "Murias1")
            userDao.insertUser(user)

            // Obtener todos los usuarios
            var allUsers = userDao.getAllUsers()
            Log.d("MARIO", allUsers.size.toString())

            //Mostrar todos los usuarios
            for(a in allUsers ){
                Log.d("MARIO", a.uid.toString() +" " +
                        a.lastName.toString() + " " + a.firstName.toString())
            }
            // Actualizar un usuario (supongamos que ya existe un usuario con el uid 1)
            val userToUpdate = allUsers.firstOrNull()
            userToUpdate?.let {
                it.firstName = "UpdatedFirstName"
                userDao.updateUser(it)
            }
            //Mostrar todos los usuarios
            for(a in allUsers ){
               Log.d("MARIO", a.lastName.toString() + " " + a.firstName.toString())
            }
            // Eliminar un usuario (supongamos que ya existe un usuario con el uid 2)
            val userToDelete = allUsers.firstOrNull { it.uid == 3 }
            userToDelete?.let {
                userDao.deleteUser(it)
            }
            allUsers = userDao.getAllUsers()
            for(a in allUsers ){
                    Log.d("MARIO", a.lastName.toString() + " " + a.firstName.toString())
            }
            //se borran todos los registros
            userDao.deleteAll()

            allUsers = userDao.getAllUsers()
            for(a in allUsers ){
                Log.d("MARIO", a.lastName.toString() + " " + a.firstName.toString())
            }
        }
    }
}


}