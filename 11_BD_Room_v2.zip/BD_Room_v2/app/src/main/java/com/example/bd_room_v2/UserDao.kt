package com.example.bd_room_v2

import androidx.room.*

@Dao
interface UserDao {
   /* @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
   fun insertUser(user: User)

*/
 @Query("SELECT * FROM users")
 fun getAllUsers(): List<User>

 @Query("SELECT * FROM users WHERE uid IN (:userIds)")
 fun loadAllByIds(userIds: IntArray): List<User>

 @Query("SELECT * FROM users WHERE first_name LIKE :first AND " +
         "last_name LIKE :last LIMIT 1")
 fun findByName(first: String, last: String): User

 @Insert
 fun insertUser(users: User)
 @Update
 fun updateUser(user: User)

 @Delete
 fun deleteUser(user: User)

 @Query("DELETE FROM users")
 fun deleteAll()
}
