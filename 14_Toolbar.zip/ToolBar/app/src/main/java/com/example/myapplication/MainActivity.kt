package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity



class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.my_toolbar1))
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.options, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.action_settings -> {
            Toast.makeText(this,"HE PULSADO CONFIGURACIÓN, ME VOY A OTRA ACTIVITY",Toast.LENGTH_LONG).show()
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
            true
        }

        R.id.action_favorite -> {
            Toast.makeText(this,"HE PULSADO FAVORITE, ME QUEDO POR AQUÍ",Toast.LENGTH_LONG).show()
            true
        }

        else -> {
            // Si la acción del usuario no se reconoce
            // se invoca la superclase para que tenga el control.
            super.onOptionsItemSelected(item)
        }
    }

}