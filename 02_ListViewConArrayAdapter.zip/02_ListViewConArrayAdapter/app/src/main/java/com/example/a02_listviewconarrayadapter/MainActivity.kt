package com.example.a02_listviewconarrayadapter

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val arrayAdapter: ArrayAdapter<*>
        val listPlayers = arrayOf(
            "LeBron James",
            "Michael Jordan",
            "Kobe Bryant",
            "Stephen Curry",
            "Kevin Durant",
            "Giannis Antetokounmpo",
            "James Harden",
            "Luka Dončić",
            "Shaquille O'Neal"
        )
        val listGames = arrayOf(
            7456,
            6325,
            5253,
            4587,
            4468,
            2456,
            4135,
            3462,
            5463
        )
        // access the listView from xml file
        val listView = findViewById<ListView>(R.id.simpleListView)
        val jugadorPartidos = findViewById<TextView>(R.id.jugadorPartidos)
        arrayAdapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1, listPlayers
        )
        listView.adapter = arrayAdapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedPlayer = listPlayers[position]
            val numberGames = listGames[position]

            //Podríamos mostrar un Toast como ejemplo de interacción
            Toast.makeText(this, "Hiciste clic en: $selectedPlayer", Toast.LENGTH_SHORT).show()

            //O un mensaje en alguna parte de la pantalla
            jugadorPartidos.setText("$selectedPlayer ha jugado " + numberGames.toString() + " partidos")


        }
    }
}