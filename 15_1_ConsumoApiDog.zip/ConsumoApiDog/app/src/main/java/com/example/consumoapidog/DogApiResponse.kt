package com.example.consumoapidog

data class DogApiResponse(
    val status: String,
    val message: String
)