package com.example.a08_preferencesdatastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("user_prefs")
class UserPreferences(private val context: Context) {

    companion object {
        val NAME_KEY = stringPreferencesKey("user_name")
        val AGE_KEY = intPreferencesKey("user_age")
    }

    // Guardar datos
    suspend fun saveUserData(name: String, age: Int) {
        context.dataStore.edit { preferences ->
            preferences[NAME_KEY] = name
            preferences[AGE_KEY] = age
        }
    }

    // Obtener datos
    val userName: Flow<String> = context.dataStore.data
        .map { preferences ->
            preferences[NAME_KEY] ?: ""
        }

    val userAge: Flow<Int> = context.dataStore.data
        .map { preferences ->
            preferences[AGE_KEY] ?: 0
        }
}