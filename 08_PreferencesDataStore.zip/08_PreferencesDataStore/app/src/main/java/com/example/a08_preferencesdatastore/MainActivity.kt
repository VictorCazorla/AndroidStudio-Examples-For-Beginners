package com.example.a08_preferencesdatastore

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.a08_preferencesdatastore.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var userPreferences: UserPreferences
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userPreferences = UserPreferences(applicationContext)

        // Recuperar datos y mostrar
        observeData()

        // Guardar datos al hacer clic en "Save"
        binding.saveButton.setOnClickListener {
            val name = binding.nameEditText.text.toString()
            val age = binding.ageEditText.text.toString().toIntOrNull() ?: 0
            saveUserData(name, age)
        }
    }
    private fun observeData() {
        // Escuchar cambios en el nombre
        lifecycleScope.launch {
            userPreferences.userName.collect { name ->
                binding.nameEditText.setText(name)
            }
        }

        // Escuchar cambios en la edad
        lifecycleScope.launch {
            userPreferences.userAge.collect { age ->
                binding.ageEditText.setText(if (age != 0) age.toString() else "")
            }
        }
    }

    private fun saveUserData(name: String, age: Int) {
        lifecycleScope.launch {
            userPreferences.saveUserData(name, age)
        }
    }

    override fun onStop() {
        super.onStop()
        val name = binding.nameEditText.text.toString()
        val age = binding.ageEditText.text.toString().toIntOrNull() ?: 0
        saveUserData(name, age)
    }
}