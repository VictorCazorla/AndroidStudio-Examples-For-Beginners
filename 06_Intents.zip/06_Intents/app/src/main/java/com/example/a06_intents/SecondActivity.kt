package com.example.a06_intents

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.a06_intents.databinding.ActivityMainBinding
import com.example.a06_intents.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySecondBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recibir los datos del Intent
        val text1 = intent.getStringExtra("EXTRA_TEXT1")
        val text2 = intent.getStringExtra("EXTRA_TEXT2")

        // Mostrar los datos en los TextView
        binding.editText1.setText(text1 + " <= Texto Recibido")
        binding.editText2.setText(text2 + " <= Texto Recibido")
    }
}