package com.example.consumoapisubdogs

data class DogRazaResponse (

        val status: String,
        val message: String

)