package com.example.consumoapisubdogs

data class DogSubRazaResponse(
    val status: String,
    val message: List<String>
)

