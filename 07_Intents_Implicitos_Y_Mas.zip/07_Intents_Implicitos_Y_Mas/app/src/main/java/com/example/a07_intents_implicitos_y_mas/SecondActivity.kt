package com.example.a07_intents_implicitos_y_mas

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.a07_intents_implicitos_y_mas.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySecondBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.button6.setOnClickListener{
// Devolveremos los datos personalizados con el resultado
            val intent = Intent()
            intent.putExtra(MainActivity.NAME, binding.name.text.toString())
            intent.putExtra(MainActivity.EMAIL, binding.email.text.toString())

// Se utiliza para establecer el RESULTADO OK y los valores de datos personalizados que queremos enviar de vuelta.
            setResult(Activity.RESULT_OK, intent)
            finish()
            
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MARIO", "DESTRUYO LA SEGUNDA ACTIVITY PORQUE NO TENGO NADA MÁS QUE HACER AQUÍ")
    }
}