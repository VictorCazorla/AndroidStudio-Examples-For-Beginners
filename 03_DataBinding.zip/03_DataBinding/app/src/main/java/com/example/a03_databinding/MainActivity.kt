package com.example.a03_databinding

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.a03_databinding.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.buttonToast.setOnClickListener { toast() }

        val color = Color.argb(255, 255, 156, 56)
        binding.usuario.setBackgroundColor(color)
        binding.lanzador.setOnClickListener{ changeBack(binding) }


    }

    private fun changeBack(binding: ActivityMainBinding){

        val color = Color.argb(255, binding.red.text.toString().toInt(),
            binding.green.text.toString().toInt(),
            binding.blue.text.toString().toInt())
//toIntOrNull(): En lugar de usar toInt(), que puede lanzar una excepción si el valor no es un número válido,
// usamos toIntOrNull() para intentar la conversión. Si no puede convertir el valor, devuelve null
// en lugar de lanzar una excepción. Luego, usamos el operador ?: (elvis operator) para asignar 0
// como valor predeterminado si la conversión falla.
        /*        val redValue = binding.red.text.toString().toIntOrNull() ?: 0
                val greenValue = binding.green.text.toString().toIntOrNull() ?: 0
                val blueValue = binding.blue.text.toString().toIntOrNull() ?: 0
        */
// Asegurarse de que los valores estén entre 0 y 255
        /*        val red = redValue.coerceIn(0, 255)
                val green = greenValue.coerceIn(0, 255)
                val blue = blueValue.coerceIn(0, 255)
        */
// Crear el color con los valores correctos
//        val color = Color.argb(255, red, green, blue)

        binding.usuario.setBackgroundColor(color)


    }
    private fun toast(){
        Toast.makeText(this,"TOASSSST",Toast.LENGTH_LONG).show()


    }
}