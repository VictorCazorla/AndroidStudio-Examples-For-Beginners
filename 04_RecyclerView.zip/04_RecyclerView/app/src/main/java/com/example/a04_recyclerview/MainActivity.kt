package com.example.a04_recyclerview

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.example.a04_recyclerview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        super.onCreate(savedInstanceState)
        val dataset = arrayOf("January", "February", "March", "April", "May")

        /** Construye un objeto de la clase CustomAdapter y a la vez, por defecto
         * se ha creado un objeto de la clase ViewHolder
         */
        val customAdapter = CustomAdapter(dataset)
        // Enlazamos con el recyclerView mediante binding
        val recyclerView: RecyclerView = binding.recyclerView

        /** Conectamos el recyclerView con la vista y con el adapter, que ya está apuntando
         *  a los datos
         */
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = customAdapter


    }
}