package com.example.a13_fab_notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.a13_fab_notifications.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Here's a Snackbar", Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .show()
        }
        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Elemento añadido", Snackbar.LENGTH_LONG)
                .setAction("Deshacer") {
                    // Código para revertir la acción
                }.show()
        }

         binding.notificationButton.setOnClickListener {
            generateNotification()
        }
        createNotificationChannel() //invocamos obligatoriamente a este método desde el OnCreate()
    }


    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //Determinamos si la versión del SDK es mayor o igual a 26 para crear el canal
            val name = getString(R.string.basic_channel_name)
            //Elegimos un nombre para el canal.
            val channelId = getString(R.string.basic_channel_id)
            //Establecemos el identificador para el canal de notificaciones que evidentemente debe ser único.
            val descriptionText = getString(R.string.basic_channel_description)
            //Definimos la descripción del canal que será visible para el usuario.

            val importance = NotificationManager.IMPORTANCE_DEFAULT
            //Establecemos la importancia para decirle al sistema cual será el nivel de interrupción
            //que tendrán las notificaciones de este canal. Usaremos la constante DEFAULT_IMPORTANCE
            // para elegir el valor por defecto.

            val channel = NotificationChannel(channelId, name, importance).apply {
                // Creamos la instancia del canal con su constructor público y los parámetros anteriores.
                // Luego invocamos a la función de alcance apply() para terminar de configurar la descripción en la misma línea.
                description = descriptionText
            }

            val nm: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            //Obtenemos la instancia del Notification Manager.
            nm.createNotificationChannel(channel)
            //Usamos a createNotificationChannel() para crear en el sistema el canal.
        // Luego de esto ya estará habilitado para liberar las notificaciones asociadas.
        }
    }

    /**   Aquí usaremos la clase NotificationCompat.Builder para crear la notificación que será mostrada.
    Para ello usaremos varios métodos set*() asociados a la construcción parcial del elemento.*/
    private fun generateNotification() {
        val notificationId = 0
        val channelId = getString(R.string.basic_channel_id) // Obtenemos el ID del canal que creamos anteriormente
        val largeIcon = BitmapFactory.decodeResource( // Generamos un Bitmap a partir de R.drawable.*,
            resources,                                // el cual será asignado en el icono grande de la notificación
            R.drawable.social_11523772

        )
        //Creamos el Builder de la notificación con el contexto actual y el ID del canal de destino
        //así como los iconos grande y pequeño, el título del contenido, el texto de soporte para el contenido
        //y el texto de cabecera
        val notification = NotificationCompat.Builder(this, channelId)
            .setLargeIcon(largeIcon)
            .setSmallIcon(R.drawable.ic_circle_notifications)
            .setContentTitle("Notificaciones En Android")
            .setContentText("NOTIFICACIÓN REALIZADA")
            .setSubText("DAM2.com")
            .setPriority(NotificationCompat.PRIORITY_MAX    ) // Determinamos el nivel de atención que debe prestarle el usuario a la notificación.
            .addAction(R.drawable.ic_bookmark,"Leer más tarde", null) // Añade un botón en el área de acciones. En este caso añadiremos una acción para «Leer más tarde».
            .build()
        ///////////////////////////////////////////////////////////////////////
        /* TENEMOS LA ESTRUCTURA CREADA, AHORA DEBEMOS LANZAR LA NOTIFICACIÓN
        * COMPROBANDO PREVIAMENTE SI TENEMOS PERMISOS PARA LANZARLA */
        with(NotificationManagerCompat.from(this)) {
            if (ActivityCompat.checkSelfPermission(
                    applicationContext,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
               return
            }
            //El primer parámetro es un entero que representa al ID de la notificación
            // con el fin de tener una referencia para actualizar o remover la notificación.
            notify(notificationId, notification)
        }
    }
}


