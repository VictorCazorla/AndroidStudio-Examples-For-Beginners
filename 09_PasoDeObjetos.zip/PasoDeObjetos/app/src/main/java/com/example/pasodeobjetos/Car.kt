package com.example.pasodeobjetos

import java.io.Serializable


class Car(val name: String, val model:String) :
    Serializable {

}