package com.example.a01_sumadosnumeros

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    lateinit var cajaResultado: TextView
    lateinit var botonSuma: Button
    lateinit var cajaNumero1: EditText
    lateinit var cajaNumero2: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cajaResultado = findViewById(R.id.resultado)
        botonSuma = findViewById<Button>(R.id.botonSuma)
        cajaNumero1 = findViewById(R.id.numero1)
        cajaNumero2 = findViewById(R.id.numero2)
        botonSuma.setOnClickListener {
            if (cajaNumero1.getText().toString().length == 0 || cajaNumero2.getText()
                    .toString().length == 0
            ) {
                cajaResultado.setText("Introduce los valores")
            } else {
                val n1 = cajaNumero1.getText().toString().toInt().toDouble()
                val n2 = cajaNumero2.getText().toString().toInt().toDouble()
                val suma = n1 + n2
                cajaResultado.setText(suma.toString())
            }
        }
    }
}